//
//  Contact.swift
//  Evichat
//
//  Created by mac on 10/29/16.
//  Copyright © 2016 com.nilesh. All rights reserved.
//

import Foundation

class Contact: NSObject {
    var name: String
    
    init(_name: String) {
        name = _name
    }
}
